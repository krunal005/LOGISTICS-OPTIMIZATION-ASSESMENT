import React from 'react';
import type { Vehicle } from '../types';

interface VehicleStatusProps {
  vehicles: Vehicle[];
}

export function VehicleStatus({ vehicles }: VehicleStatusProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold mb-4">Vehicle Status</h2>
      <div className="space-y-4">
        {vehicles.map((vehicle) => (
          <div key={vehicle.id} className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h3 className="font-medium">{vehicle.name}</h3>
              <p className="text-sm text-gray-500">Capacity: {vehicle.capacity}kg</p>
            </div>
            <span className={`px-2 py-1 text-xs font-semibold rounded-full
              ${vehicle.status === 'available' ? 'bg-green-100 text-green-800' : 
                vehicle.status === 'on_delivery' ? 'bg-yellow-100 text-yellow-800' : 
                'bg-red-100 text-red-800'}`}>
              {vehicle.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}