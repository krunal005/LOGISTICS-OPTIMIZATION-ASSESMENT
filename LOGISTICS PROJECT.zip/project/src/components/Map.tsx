import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { Truck } from 'lucide-react';
import type { Vehicle, DeliveryOrder } from '../types';

interface MapProps {
  vehicles: Vehicle[];
  orders: DeliveryOrder[];
}

export function Map({ vehicles, orders }: MapProps) {
  const defaultCenter = { lat: 40.7128, lng: -74.0060 }; // New York City

  return (
    <div className="h-[600px] w-full rounded-lg overflow-hidden shadow-lg">
      <MapContainer
        center={[defaultCenter.lat, defaultCenter.lng]}
        zoom={12}
        className="h-full w-full"
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        {vehicles.map((vehicle) => (
          <Marker
            key={vehicle.id}
            position={[vehicle.currentLocation.latitude, vehicle.currentLocation.longitude]}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-bold">{vehicle.name}</h3>
                <p>Status: {vehicle.status}</p>
                <p>Capacity: {vehicle.capacity}kg</p>
              </div>
            </Popup>
          </Marker>
        ))}

        {orders.map((order) => (
          <Marker
            key={order.id}
            position={[order.latitude, order.longitude]}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-bold">{order.customerName}</h3>
                <p>{order.address}</p>
                <p>Status: {order.status}</p>
                <p>Priority: {order.priority}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}