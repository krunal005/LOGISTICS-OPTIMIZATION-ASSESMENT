import React from 'react';
import { Map } from './Map';
import { Metrics } from './Metrics';
import { OrderList } from './OrderList';
import { VehicleStatus } from './VehicleStatus';
import { Activity, Package, Truck } from 'lucide-react';

export function Dashboard() {
  // Placeholder data - will be replaced with real data from Supabase
  const vehicles = [
    {
      id: '1',
      name: 'Truck 1',
      capacity: 1000,
      currentLocation: { latitude: 40.7128, longitude: -74.0060 },
      status: 'available'
    }
  ];

  const orders = [
    {
      id: '1',
      customerName: 'John Doe',
      address: '123 Main St, New York, NY',
      latitude: 40.7128,
      longitude: -74.0060,
      priority: 'high',
      weight: 100,
      status: 'pending',
      estimatedDeliveryTime: '2024-03-15T15:00:00Z',
      created_at: '2024-03-15T10:00:00Z'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Truck className="h-8 w-8 text-blue-600" />
              <h1 className="ml-3 text-3xl font-bold text-gray-900">TransLogi</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 mb-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Package className="h-6 w-6 text-blue-600" />
              <h2 className="ml-3 text-lg font-semibold">Active Orders</h2>
            </div>
            <p className="mt-2 text-3xl font-bold">24</p>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Truck className="h-6 w-6 text-green-600" />
              <h2 className="ml-3 text-lg font-semibold">Available Vehicles</h2>
            </div>
            <p className="mt-2 text-3xl font-bold">8</p>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Activity className="h-6 w-6 text-purple-600" />
              <h2 className="ml-3 text-lg font-semibold">On-Time Delivery</h2>
            </div>
            <p className="mt-2 text-3xl font-bold">95%</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Map vehicles={vehicles} orders={orders} />
          </div>
          <div>
            <VehicleStatus vehicles={vehicles} />
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Metrics />
          <OrderList orders={orders} />
        </div>
      </main>
    </div>
  );
}