export interface DeliveryOrder {
  id: string;
  customerName: string;
  address: string;
  latitude: number;
  longitude: number;
  priority: 'low' | 'medium' | 'high';
  weight: number;
  status: 'pending' | 'in_progress' | 'delivered';
  estimatedDeliveryTime: string;
  actualDeliveryTime?: string;
  created_at: string;
}

export interface Vehicle {
  id: string;
  name: string;
  capacity: number;
  currentLocation: {
    latitude: number;
    longitude: number;
  };
  status: 'available' | 'on_delivery' | 'maintenance';
}

export interface Route {
  id: string;
  vehicleId: string;
  orders: string[];
  estimatedDuration: number;
  distance: number;
  created_at: string;
}

export interface WeatherData {
  temperature: number;
  condition: string;
  windSpeed: number;
  precipitation: number;
}